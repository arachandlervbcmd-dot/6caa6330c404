// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Model riptide flow\n", stdout);
  return lionss_run_workload("riptide");
}
