// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Grow glass fern"); }
int main(){
  announce();
  return lionss_run_workload("glassfern");
}
