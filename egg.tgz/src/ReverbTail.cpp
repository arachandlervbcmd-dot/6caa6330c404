// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render reverb tail\n", stdout);
  return lionss_run_workload("ReverbTail");
}
