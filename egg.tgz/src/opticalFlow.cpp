// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Estimate optical flow"); }
int main(){
  announce();
  return lionss_run_workload("opticalFlow");
}
