// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Animate blue heron\n", stdout);
  return lionss_run_workload("BlueHeron");
}
