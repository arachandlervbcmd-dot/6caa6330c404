// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply NAT rules"); }
int main(){
  announce();
  return lionss_run_workload("nftables-nat");
}
