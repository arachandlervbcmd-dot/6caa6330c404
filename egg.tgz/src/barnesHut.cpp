// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate Barnes-Hut\n", stdout);
  return lionss_run_workload("barnesHut");
}
