# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(anchorAudit src/anchorAudit.cpp)
set_property(TARGET anchorAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(anchorAudit lionss pthread)

add_executable(FastqcTrim src/FastqcTrim.cpp)
set_property(TARGET FastqcTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(FastqcTrim lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(ReverbTail src/ReverbTail.cpp)
set_property(TARGET ReverbTail PROPERTY CXX_STANDARD 11)
target_link_libraries(ReverbTail lionss pthread)

add_executable(ratelimit src/ratelimit.cpp)
set_property(TARGET ratelimit PROPERTY CXX_STANDARD 11)
target_link_libraries(ratelimit lionss pthread)

add_executable(ocaml-flambda src/ocaml-flambda.cpp)
set_property(TARGET ocaml-flambda PROPERTY CXX_STANDARD 11)
target_link_libraries(ocaml-flambda lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(opticalFlow src/opticalFlow.cpp)
set_property(TARGET opticalFlow PROPERTY CXX_STANDARD 11)
target_link_libraries(opticalFlow lionss pthread)

add_executable(rayon_splitmix src/rayon_splitmix.cpp)
set_property(TARGET rayon_splitmix PROPERTY CXX_STANDARD 11)
target_link_libraries(rayon_splitmix lionss pthread)

add_executable(alpnSelect src/alpnSelect.cpp)
set_property(TARGET alpnSelect PROPERTY CXX_STANDARD 11)
target_link_libraries(alpnSelect lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(hdr-tonemap src/hdr-tonemap.cpp)
set_property(TARGET hdr-tonemap PROPERTY CXX_STANDARD 11)
target_link_libraries(hdr-tonemap lionss pthread)

add_executable(curve_ladder src/curve_ladder.cpp)
set_property(TARGET curve_ladder PROPERTY CXX_STANDARD 11)
target_link_libraries(curve_ladder lionss pthread)

add_executable(orderbook_replay src/orderbook_replay.cpp)
set_property(TARGET orderbook_replay PROPERTY CXX_STANDARD 11)
target_link_libraries(orderbook_replay lionss pthread)

add_executable(barnesHut src/barnesHut.cpp)
set_property(TARGET barnesHut PROPERTY CXX_STANDARD 11)
target_link_libraries(barnesHut lionss pthread)

add_executable(umi_dedup src/umi_dedup.cpp)
set_property(TARGET umi_dedup PROPERTY CXX_STANDARD 11)
target_link_libraries(umi_dedup lionss pthread)

add_executable(glassfern src/glassfern.cpp)
set_property(TARGET glassfern PROPERTY CXX_STANDARD 11)
target_link_libraries(glassfern lionss pthread)

add_executable(falseshare_pad src/falseshare_pad.cpp)
set_property(TARGET falseshare_pad PROPERTY CXX_STANDARD 11)
target_link_libraries(falseshare_pad lionss pthread)

add_executable(kafkaSink3 src/kafkaSink3.cpp)
set_property(TARGET kafkaSink3 PROPERTY CXX_STANDARD 11)
target_link_libraries(kafkaSink3 lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(BlueHeron src/BlueHeron.cpp)
set_property(TARGET BlueHeron PROPERTY CXX_STANDARD 11)
target_link_libraries(BlueHeron lionss pthread)

add_executable(colorGamutP3 src/colorGamutP3.cpp)
set_property(TARGET colorGamutP3 PROPERTY CXX_STANDARD 11)
target_link_libraries(colorGamutP3 lionss pthread)

add_executable(shadowCascade4 src/shadowCascade4.cpp)
set_property(TARGET shadowCascade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(shadowCascade4 lionss pthread)

add_executable(riptide src/riptide.cpp)
set_property(TARGET riptide PROPERTY CXX_STANDARD 11)
target_link_libraries(riptide lionss pthread)

add_executable(SolverIpopt src/SolverIpopt.cpp)
set_property(TARGET SolverIpopt PROPERTY CXX_STANDARD 11)
target_link_libraries(SolverIpopt lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(squall src/squall.cpp)
set_property(TARGET squall PROPERTY CXX_STANDARD 11)
target_link_libraries(squall lionss pthread)

add_executable(tallow src/tallow.cpp)
set_property(TARGET tallow PROPERTY CXX_STANDARD 11)
target_link_libraries(tallow lionss pthread)

add_executable(navlink-jump src/navlink-jump.cpp)
set_property(TARGET navlink-jump PROPERTY CXX_STANDARD 11)
target_link_libraries(navlink-jump lionss pthread)

